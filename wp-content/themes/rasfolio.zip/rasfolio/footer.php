
  <!-- ###########Footer############# -->
  <!-- Footer Section -->
  <footer>
    <div class="container mt-3"> 
        <div class="footer-item-container">
            <div class="copyright p-1">
                <p>Copyright &copy;</p> &nbsp;
                <p class="year"></p> &nbsp;
                <a href="https://www.rusulazom.xyz" target="_blank">Rusul Azom Sumon</a> &nbsp; 
                <p>All Rights Reserved</p>
                <!-- back to top button -->
                <!-- Back to Top -->
                  <!-- <a href="#" class="btn btn-primary btn-square back-to-top"><i class="fa fa-arrow-up"></i></a> -->
            </div>
        </div>
    </div>
</footer>

  
  <!-- for showing wp admint ber in the top -->
  <?php wp_footer(); ?>
  </body>
</html>

    <!-- including header -->
    <?php
        /*
        Template Name: Blog Page
        */
        get_header();
    ?>

    <div class="blog-page contianer">
        <div class="blog-contents row">
            <h1>Md. Rusul Azom sumon</h1>
        </div>
    </div>

    <!-- including footer -->
    <?php
    
        get_footer();
    ?>